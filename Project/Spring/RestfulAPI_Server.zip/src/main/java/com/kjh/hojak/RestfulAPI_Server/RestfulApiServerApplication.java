package com.kjh.hojak.RestfulAPI_Server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulApiServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulApiServerApplication.class, args);
	}
}
